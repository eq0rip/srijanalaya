	=== Custom Login Page Customizer ===
Version: 1.0.1
Requires at least: 4.0
Tested up to: 4.3
Contributors: codeinwp, hardeepasrani,marius_codeinwp
Author URI: https://themeisle.com
Tags: login, customizer, logo, login logo, login customizer, login page,admin, branding, customization, custom login, error, login error, custom login pro
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom Login Customizer allows you to easily customize your admin login page, straight from your WordPress Customizer!

== Description ==

><a href="https://themeisle.com/plugins/login-customizer/" target="_blank" rel="friend">Custom Login Page Customizer</a> plugin allows you to easily customize your login page straight from your WordPress Customizer! You can preview your custom login changes before you save them! Awesome, right?

In your WordPress Dashboard, navigate to Appearance > Custom Login Page Customizer to get started.

### Why to upgrade to PRO ?

Using the <a rel="friend" href="http://themeisle.com/plugins/custom-login-customizer-security-addon/">SECURITY ADDON</a> of the plugin you will prevents robots and brute force attacks to your website using reCAPTCHA integration and limit login feature.

Upcoming Custom Login Page Customizer features:

- Templates
- Advanced authentification

You can customize almost anything and make it look the way you want.

If you are looking for the best WordPress themes check this out : <a href="http://www.codeinwp.com/blog/10-best-bootstrap-based-wordpress-themes/" target="_blank" rel="friend">http://www.codeinwp.com/blog/10-best-bootstrap-based-wordpress-themes/</a>
== Installation ==

1. Upload the plugin to your 'wp-content/plugins' directory, or download and install automatically through your admin panel.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= How to customizer? =

In your WordPress Dashboard, navigate to Appearance > Custom Login Customizer to get started.

= How to donate or contribute? =

Please visit <a target="_blank" rel="friend" href="http://themeisle.com">this link</a> for more info.

== Screenshots ==

1. Example Custom Login Page
2. Another Great Custom Login Page Example